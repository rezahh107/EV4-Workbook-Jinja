# CHANGELOG

## 29.0

- افزودن ۲۸ بخش «تنظیمات، مقدارها و واحدها».
- افزودن اطلس مرکزی واحدها و مرزبندی Elementor UI در برابر CSS Platform.
- افزودن Step‑Through v2 محاسباتی با ۸ مرحله برای rem، em، درصد، vw، dvh، fr و ms.
- افزودن مثال‌های ریاضی، یادداشت Responsive و چک DevTools در هر درس.
- اصلاح ارتفاع نامتوازن disclosureهای دارای کلاس lesson-section.
- افزودن Registry و منابع رسمی v29.

## 28.0

- افزودن ۲۸ مرجع مفهومی بسته‌شونده، یک مرجع برای هر درس اصلی و تکمیلی.
- بازنویسی مرجع Position با اصلاح containing block، Fixed، Sticky، z-index و مسیر V4.
- افزودن Registry منابع و استاندارد تحریریهٔ مرجع مفهومی.
- حفظ Step‑Through v2، تمرین‌های Responsive، یافته‌های عملی و Progressive Disclosure.
- تفکیک منابع رسمی محصول، CSS specification و استعارهٔ آموزشی.

فارسی

## 27.0

- موتور داده‌محور Step-Through v2 با Schema نسخه‌بندی‌شده افزوده شد.
- چهار شبیه‌ساز مرجع برای Width/Overflow، Flex Axis، Responsive Inheritance و Class Priority پیاده‌سازی شدند.
- پیش‌بینی فعال، پاسخ آشکارشدنی، سه نمای Visual/Elementor/Computed و ذخیرهٔ پیشرفت افزوده شد.
- Step-Through سادهٔ justify-content با نسخهٔ عمیق‌تر Flex Axis جایگزین شد.
- پیوند دوطرفه با تمرین‌های «بساز و امتحان کن» اضافه شد.
- fallback چاپی، keyboard، aria-live و reduced motion اعتبارسنجی شدند.
- ادعای تبدیل کامل همهٔ درس‌ها مطرح نشد.

## 26.0

- 15 Responsive Build & Test Lab به درس‌های مرتبط افزوده شد.
- Boss Lab جامع TUYA Responsive با پنج خرابی عمدی و گیت قبولی افزوده شد.
- هر تمرین شامل پیش‌بینی، تست بین breakpointها و بررسی Computed Style است.
- همهٔ تمرین‌ها در حالت اولیه بسته و در چاپ قابل مشاهده‌اند.
- مفاهیم با Help Center رسمی Elementor V4 تطبیق داده شدند.
- هیچ breakpoint، رفتار Tablet یا مقدار CSS دیده‌نشده به‌عنوان حقیقت قطعی افزوده نشد.

## 25.0

- طرح Mobile TUYA به assets و provenance اضافه شد.
- کارگاه Responsive TUYA افزوده شد.
- 15 Responsive checkpoint به درس‌های مرتبط افزوده شد.
- تمام محتوای غیرهسته‌ای lesson articleها به disclosure بسته در حالت پیش‌فرض تبدیل شد.
- لینک‌های داخلی اکنون disclosure والد را باز می‌کنند.
- مفاهیم responsive با Help Center رسمی Elementor V4 هم‌تراز شدند.
- ادعاهای مربوط به Tablet و اندازه‌های دقیق که در Screenshot دیده نمی‌شوند، proposed/insufficient_evidence باقی ماندند.

## 24.0

- یافته‌های عملی و Help Center به انتهای درس‌های مرتبط افزوده شدند.
