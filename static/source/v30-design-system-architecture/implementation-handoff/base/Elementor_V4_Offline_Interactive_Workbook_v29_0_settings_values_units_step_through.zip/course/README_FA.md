# کتاب‌کار تعاملی آفلاین Elementor V4 — نسخه 29.0

این بسته نسخهٔ کامل v29.0 و مستقیماً مبتنی بر v28.0 است.

## تغییر اصلی v29

برای همهٔ ۲۸ درس اصلی و تکمیلی بخش بسته‌شوندهٔ «⚙️ تنظیمات، مقدارها و واحدها» اضافه شد. هر بخش نوع کنترل، Property، واحد/keyword/reference، مرجع محاسبه، انتخاب پیشنهادی، تله، Responsive و مسیر بررسی DevTools را توضیح می‌دهد.

یک اطلس مرکزی و Step‑Through محاسباتی نیز اضافه شده است تا تفاوت `px`، `rem`، `em`، `%`، `vw/dvh`، `fr` و `ms` با مثال عددی روشن شود.

## مرزبندی مهم

- Help Center رسمی Elementor منبع واحدهای عرضه‌شده در UI است.
- W3C/CSSWG و MDN منبع رفتار CSS هستند.
- پشتیبانی CSS به‌معنای وجود واحد در همهٔ کنترل‌های Elementor نیست.
- توصیه‌ها context-aware هستند و هیچ واحدی به‌صورت جهانی بهترین اعلام نشده است.

## اصلاح UI

ارتفاع نامتوازن ردیف‌های بسته‌شونده که از padding کلاس `lesson-section` روی خود `<details>` ایجاد می‌شد اصلاح شد. ردیف‌های تک‌خطی اکنون حداقل ارتفاع و padding یکنواخت دارند؛ عنوان‌های چندخطی همچنان برای دسترسی‌پذیری اجازهٔ رشد طبیعی دارند.

## فایل‌های جدید

- `source/v29-settings-values-units/SETTINGS_VALUES_UNITS_STANDARD_FA.md`
- `source/v29-settings-values-units/unit_context_registry_v29.json`
- `source/v29-settings-values-units/official_sources_v29.json`
- `source/v29-settings-values-units/UNIT_ATLAS_FA.md`

## اجرای آفلاین

فایل `index.html` را در مرورگر باز کنید. هیچ asset فعال خارجی برای اجرای جزوه لازم نیست.
